package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		
	}
	
	
	
				// action+ElementName
	public LoginPage enterUsername(String uName) throws InterruptedException, IOException {
		
		try {
			driver.findElement(By.id("username")).sendKeys(uName);
			reportStep(uName+" username is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(uName+" username is not entered successfully"+e, "fail");
		}
		
		return this;
		
	}

	public LoginPage enterPassword(String pWord) throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys(pWord);
			reportStep(pWord+" password is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(pWord+" password is not entered successfully"+e, "fail");
		}
		return this;
	}

	public HomePage clickLoginButton() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("login button is clicked", "pass");
		} catch (Exception e) {
			reportStep("login button is not clicked", "fail");
		}
			
		return new HomePage(driver);
	}

}
